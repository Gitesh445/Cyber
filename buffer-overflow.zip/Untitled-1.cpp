#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];
  int arr_num;
  int num,i;

   cout << "Enter the count of numbers? ";
   cin >> arr_num;

  for (i = 0; i < arr_num; i++)
  {
    cout << "Enter a number to be stored: ";
    cin >> num;
    arr[i]= num;
  }
  return 0;
}
