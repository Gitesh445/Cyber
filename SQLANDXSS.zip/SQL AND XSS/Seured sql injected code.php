<?php
        if(isset($_POST['submit']))
          
        {   /** this is extra code */
            $id = $_POST['id'];

            /** validating data to prevent sql injection*/
            if (is_numeric($id) == true){
                try {
                    /** setting up connection */
                    include 'connection.php';
                }
            }
            /** extra code ends here */

            $username = $_POST['username'];
            $email = $_POST['email'];
            $query = "UPDATE users SET username = '$username', email = '$email' WHERE id = '$id'";
            $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
            header("Location: index.php");
        }  
        if(isset($_POST['logout']))
        {
            unset($_SESSION['id']);
            session_destroy();
            header("Location: index.php");
        }            
?>