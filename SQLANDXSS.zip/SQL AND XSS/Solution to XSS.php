<?php
    if (isset($_POST['email'])) {
        echo filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        echo "<br/><br/>";
    }
 
    if (isset($_POST['username'])) {
        echo filter_var($_POST['username'], FILTER_SANITIZE_STRING);
        echo "<br/><br/>";
    }
?>


/** tis way with proper sanitization we could secure our vulrnable php code from XSS attack ie Cross site scripting attack */